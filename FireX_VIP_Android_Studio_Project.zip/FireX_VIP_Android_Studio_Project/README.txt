FireX VIP Android Studio project

WHAT WORKS
- Interactive toggles inside the app
- Local visual reticle preview with adjustable size and intensity
- Contrast/preview toggles, theme switch, demo FPS label
- Settings saved locally on the device
- Android WebView wrapper and app label

SAFETY
These are local app demonstrations only. The app does not connect to, read, or modify Free Fire and does not implement aimbot/wallhack/game cheats.

BUILD APK
1. Open this project folder in Android Studio.
2. Allow Gradle sync and install Android SDK Platform 35 / Build Tools when prompted.
3. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The debug APK is usually created under app/build/outputs/apk/debug/app-debug.apk.

This package is Android source code, not a precompiled APK. A compatible Android SDK/Gradle build environment is required to compile it.
